import React from 'react';
import NextHead from 'next/head';

const Head = () => (
    <NextHead>
        <title>Institutions Lookup</title>
    </NextHead>
);

export default Head;
